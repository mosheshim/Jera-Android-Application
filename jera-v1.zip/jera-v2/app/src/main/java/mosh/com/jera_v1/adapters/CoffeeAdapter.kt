package mosh.com.jera_v1.adapters

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import mosh.com.jera_v1.R
import mosh.com.jera_v1.databinding.CoffeeItemBinding
import mosh.com.jera_v1.dialogs.AddToCartDialog
import mosh.com.jera_v1.models.CoffeeModel
import java.util.zip.Inflater

class CoffeeAdapter(val coffeeList: List<CoffeeModel>) :
    RecyclerView.Adapter<CoffeeAdapter.ViewHolder>() {

    class ViewHolder(val binding: CoffeeItemBinding) : RecyclerView.ViewHolder(binding.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CoffeeAdapter.ViewHolder {
        return ViewHolder(
            CoffeeItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CoffeeAdapter.ViewHolder, position: Int) {
        val coffee = coffeeList[position]
        holder.binding.textName.text = coffee.name
        holder.binding.textRoastinLevel.text = "${coffee.roastingLevel} Roast"
        holder.binding.textTasteProfile.text = "Taste Of ${coffee.tasteProfile}"
        holder.binding.textPrice.text = "${coffee.price} shekels"

        holder.itemView.setOnClickListener {
            showDialog(coffee,holder)
        }

    }

    override fun getItemCount(): Int = coffeeList.size



    @SuppressLint("ResourceType")
    fun showDialog(coffee : CoffeeModel  , holder: CoffeeAdapter.ViewHolder) {
        try {
            val activity: Activity = holder.binding.root.context as Activity
            val myContext : FragmentActivity =  activity as FragmentActivity
            val manager = myContext.supportFragmentManager
            AddToCartDialog.newInstance(coffee, manager)
        }catch (e : Exception) {
            println(e)
        }

    }
}
