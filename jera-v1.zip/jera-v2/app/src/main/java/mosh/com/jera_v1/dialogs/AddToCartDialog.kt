package mosh.com.jera_v1.dialogs

import android.app.AlertDialog
import android.app.Dialog
import android.os.Build
import android.os.Bundle
import android.text.Editable
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import mosh.com.jera_v1.R
import mosh.com.jera_v1.models.Cart
import mosh.com.jera_v1.models.CartItem
import mosh.com.jera_v1.models.CoffeeModel

class AddToCartDialog : DialogFragment() {


    companion object {
        const val TAG = "PurchaseConfirmationDialog"

        private var coffeeItem: CoffeeModel? = null
        fun newInstance(coffeeToShow: CoffeeModel, fragmentManager: FragmentManager){
            coffeeItem = coffeeToShow
            AddToCartDialog().show(fragmentManager, TAG)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_add_to_cart_dialog, container, false)
        val coffee = coffeeItem
        if (coffee != null) {
            val tName: TextView = view.findViewById(R.id.text_name_ad)
            tName.text = coffee.name

            val tRoastingL: TextView = view.findViewById(R.id.text_roasting_level_ad)
            tRoastingL.text = "Roasting Level: ${coffee.roastingLevel}"

            val tCountry: TextView = view.findViewById(R.id.text_country_of_origin_ad)
            tCountry.text = "Originate From ${coffee.countryOfOrigin}"

            val tTaste: TextView = view.findViewById(R.id.text_taste_profile_ad)
            tTaste.text = "Taste Of ${coffee.tasteProfile}"

            val tDescription: TextView = view.findViewById(R.id.text_description_ad)
            tDescription.text = "Description:\n${coffee.description}"

            val tPrice: TextView = view.findViewById(R.id.text_price_ad)
            tPrice.text = "${coffee.price} Shekels Per 250g (1 bag)"


            val quantityInput: EditText = view.findViewById(R.id.input_quantity_ad)
            val arrowUp: ImageButton = view.findViewById(R.id.button_arrow_up)
                arrowUp.setOnClickListener{
                    quantityInput.apply {setText((text.toString().toInt() + 1).toString())}
            }

            val arrowDown: ImageButton = view.findViewById(R.id.button_arrow_down)
            arrowDown.setOnClickListener{
                quantityInput.apply {
                    val num = text.toString().toInt()
                    if (num > 1) setText((text.toString().toInt() - 1).toString())}
            }


            val btnCancel: Button = view.findViewById(R.id.button_go_back)
            btnCancel.setOnClickListener{
                dismiss()
            }
            val btnAddCart: Button = view.findViewById(R.id.button_add_to_cart)
            btnAddCart.setOnClickListener{
                Toast.makeText(context, "Added To Cart", Toast.LENGTH_SHORT).show()
                val qty:Int = quantityInput.text.toString().toInt()
                Cart.addToCart(CartItem(coffee, qty))
                dismiss()
            }
        }

        return view
    }



}

