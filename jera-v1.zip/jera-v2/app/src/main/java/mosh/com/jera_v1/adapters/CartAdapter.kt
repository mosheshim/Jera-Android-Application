package mosh.com.jera_v1.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import mosh.com.jera_v1.databinding.CartItemBinding
import mosh.com.jera_v1.databinding.CoffeeItemBinding
import mosh.com.jera_v1.models.Cart
import mosh.com.jera_v1.models.CartItem

class CartAdapter : RecyclerView.Adapter<CartAdapter.ViewHolder>() {

    class ViewHolder(val binding: CartItemBinding) : RecyclerView.ViewHolder(binding.root){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            CartItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: CartAdapter.ViewHolder, position: Int) {
        val item: CartItem = Cart.items[position]
        holder.binding.textNameCi.text = item.coffee.name
        holder.binding.textQuantityCi.text = item.quantity.toString()
        holder.binding.textPriceCi.text = "$${item.coffee.price * item.quantity}"
            }

    override fun getItemCount(): Int = Cart.items.size

}