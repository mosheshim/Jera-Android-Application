package mosh.com.jera_v1

const val LIGHT = "Light"
const val MEDIUM = "Medium"
const val DARK = "Dark"