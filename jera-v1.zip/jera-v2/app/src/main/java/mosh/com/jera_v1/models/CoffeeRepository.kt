package mosh.com.jera_v1.models

import mosh.com.jera_v1.DARK
import mosh.com.jera_v1.LIGHT
import mosh.com.jera_v1.MEDIUM

class CoffeeRepository {
    companion object{
        fun getCoffeeList(): List<CoffeeModel>{
            return mutableListOf<CoffeeModel>().apply {
                add(
                    CoffeeModel(
                    "Colombia Organic",
                    "Colombia",
                    35,
                    MEDIUM,
                        "Cacao, Chocolate, Dry fruits",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue nibh non rutrum iaculis. Aliquam erat volutpat. Mauris eleifend ut velit id vulputate. Aliquam vel eros neque. Donec vel sem a felis semper congue. Nunc vitae nibh a purus maximus rhoncus. Morbi massa ipsum, feugiat eget ex eu, vehicula egestas. ",
                    1
                )
                )
                add(
                    CoffeeModel(
                        "Brazil Cerrado",
                        "Brazil",
                        28,
                        MEDIUM,
                        "Nuts, Milk Chocolate",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue nibh non rutrum iaculis. Aliquam erat volutpat. Mauris eleifend ut velit id vulputate. Aliquam vel eros neque. Donec vel sem a felis semper congue. Nunc vitae nibh a purus maximus rhoncus. Morbi massa ipsum, feugiat eget ex eu, vehicula egestas. ",
                    2
                    )
                )
                add(
                    CoffeeModel(
                        "Santo Domingo",
                        "Demoniac Republic",
                        38,
                        DARK,
                        "Cacao, Vanil",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue nibh non rutrum iaculis. Aliquam erat volutpat. Mauris eleifend ut velit id vulputate. Aliquam vel eros neque. Donec vel sem a felis semper congue. Nunc vitae nibh a purus maximus rhoncus. Morbi massa ipsum, feugiat eget ex eu, vehicula egestas. ",
                        3
                    )
                )
                add(
                    CoffeeModel(
                        "Kenya Kiganjo AA",
                        "Kenya",
                        50,
                        LIGHT,
                        "Tea with Lemon, Red Berries",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue nibh non rutrum iaculis. Aliquam erat volutpat. Mauris eleifend ut velit id vulputate. Aliquam vel eros neque. Donec vel sem a felis semper congue. Nunc vitae nibh a purus maximus rhoncus. Morbi massa ipsum, feugiat eget ex eu, vehicula egestas. ",
                        4
                    )
                )
            }
        }
    }
}