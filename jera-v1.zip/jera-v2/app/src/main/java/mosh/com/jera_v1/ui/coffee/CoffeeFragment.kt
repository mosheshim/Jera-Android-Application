package mosh.com.jera_v1.ui.coffee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import mosh.com.jera_v1.adapters.CoffeeAdapter
import mosh.com.jera_v1.databinding.FragmentCoffeeBinding
import mosh.com.jera_v1.models.CoffeeRepository
import java.text.FieldPosition

class CoffeeFragment : Fragment(){

    private lateinit var CoffeeView: CoffeeViewModel
    private var _binding: FragmentCoffeeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        CoffeeView =
            ViewModelProvider(this).get(CoffeeViewModel::class.java)

        _binding = FragmentCoffeeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvCoffee.adapter = CoffeeAdapter(CoffeeRepository.getCoffeeList())
        binding.rvCoffee.layoutManager = LinearLayoutManager(requireContext())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}