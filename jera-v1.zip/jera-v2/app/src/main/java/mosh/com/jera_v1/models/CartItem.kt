package mosh.com.jera_v1.models

class CartItem(val coffee: CoffeeModel, val quantity: Int) {
}