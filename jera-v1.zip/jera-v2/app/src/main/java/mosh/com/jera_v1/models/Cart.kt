package mosh.com.jera_v1.models

import android.icu.text.AlphabeticIndex

class Cart {
    companion object {
        val items: MutableList<CartItem> = mutableListOf()


        fun addToCart(cartItem: CartItem) {
            items.add(cartItem)

        }
        fun totalPrice(): Int{
            var totalPrice = 0
            items.forEach {totalPrice += it.coffee.price * it.quantity}
            return totalPrice
        }

    }
}