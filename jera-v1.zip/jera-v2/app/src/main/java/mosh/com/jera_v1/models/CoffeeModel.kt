package mosh.com.jera_v1.models

class CoffeeModel(
    val name: String,
    val countryOfOrigin: String,
    val price: Int,
    val roastingLevel: String,
    val tasteProfile: String,
    val description : String,
    val id: Int
){
}