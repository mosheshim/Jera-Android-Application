package mosh.com.jera_v1

import com.google.android.material.bottomnavigation.BottomNavigationView

class NavSharing {
    companion object{
        var navView : BottomNavigationView? = null
    }
}