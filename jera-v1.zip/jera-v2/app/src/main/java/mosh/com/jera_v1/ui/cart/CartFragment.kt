package mosh.com.jera_v1.ui.cart

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.navigation.NavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import mosh.com.jera_v1.MainActivity
import mosh.com.jera_v1.NavSharing.Companion.navView
import mosh.com.jera_v1.R
import mosh.com.jera_v1.adapters.CartAdapter
import mosh.com.jera_v1.databinding.FragmentCartBinding
import mosh.com.jera_v1.models.Cart


class CartFragment : Fragment() {

    private var _binding: FragmentCartBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCartBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvCart.adapter = CartAdapter()
        binding.rvCart.layoutManager = LinearLayoutManager(requireContext())
        binding.textTotalPrice.text = "Total Of $${Cart.totalPrice()}"
        binding.buttonGoBackCartFrag.setOnClickListener{
                val fm : FragmentManager = requireActivity().supportFragmentManager
                fm.popBackStack()
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        navView?.visibility = View.VISIBLE
        _binding = null

    }

}